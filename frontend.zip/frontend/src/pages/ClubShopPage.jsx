function ClubShopPage() {
    return (
      <div style={{ padding: '1rem', textAlign: 'center' }}>
        <h2>Club Shop</h2>
        <p>This page will show all listings posted by official KFUPM clubs.</p>
      </div>
    );
  }
  
  export default ClubShopPage;
  